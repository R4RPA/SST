import os
import glob
import re
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

pd.options.mode.chained_assignment = None

class ProvidersCompleteAnalysis:
    """
        A class for analyzing and visualizing healthcare provider completion percentages.

        This class loads and analyzes data related to healthcare providers, their completion percentages,
        and generates various types of charts and graphs for visualization.

        Parameters:
        - site (str): The healthcare site to analyze.
        - start_date (str, optional): The start date for filtering data (default is None).
        - end_date (str, optional): The end date for filtering data (default is None).
        - max_providers_per_chart (int): The maximum number of providers to display per chart (default is 10).

        Attributes:
        - max_providers_per_chart (int): The maximum number of providers to display per chart.
        - site (str): The healthcare site being analyzed.
        - start_date (str, optional): The start date for data filtering.
        - end_date (str, optional): The end date for data filtering.
        - data_df (DataFrame): The main data DataFrame.
        - providers_df (DataFrame): DataFrame containing provider information.
        - filtered_df (DataFrame): DataFrame containing filtered data.
        - agg_df (DataFrame): DataFrame containing aggregated data.

        Methods:
        - load_data(): Load data from CSV files.
        - set_charts_path(): Set up directory structure for storing generated charts.
        - merge_data(): Merge provider data with main data.
        - filter_data(): Apply data filters based on site and date range.
        - handle_na_proper_name(): Handle missing proper names in the data.
        - preprocess_data(): Preprocess data, convert date columns to datetime, and extract month.
        - aggregate_data(): Aggregate data to calculate completion percentages.
        - plot_overall_graph(): Generate an overall completion percentage graph.
        - plot_individual_graphs(): Generate individual completion percentage graphs for each provider.
        - plot_grouped_graphs(): Generate grouped completion percentage graphs.
        """

    def __init__(self, site, start_date=None, end_date=None, max_providers_per_chart=10):
        self.max_providers_per_chart = max_providers_per_chart
        self.site = site
        self.start_date = start_date
        self.end_date = end_date
        self.data_df = None
        self.providers_df = None
        self.filtered_df = None
        self.agg_df = None
        self.load_data()
        self.charts_path = 'charts'
        self.charts_provider_path = 'charts/provider'
        self.charts_group_path = 'charts/group'
        self.set_charts_path()

    def load_data(self):
        """ Load data from data wide and provides CSV files."""
        user = os.getenv("LOGNAME")
        redcap_downloads = f"/Users/{user}/Dropbox (Partners HealthCare)/ELHS DCC/g. CODING_DASHBOARDS/REDCap Downloads/"
        files = glob.glob(os.path.join(redcap_downloads, "df_wide_*.csv"))
        max_date = max(
            (datetime.strptime(re.search(r'(\d{4}_\d{2}_\d{2})', os.path.basename(file)).group(1), '%Y_%m_%d').date()
             for file in files), default=None)
        filedate = max_date.strftime('%Y_%m_%d').replace("-", "_") if max_date else None
        data_wide_file_path = os.path.join(redcap_downloads, f"df_wide_{filedate}.csv")
        providers_file_path = "provider_list.csv"
        self.data_df = pd.read_csv(data_wide_file_path, usecols=['elhs_site_options', 'provider', 'sz_provider_complete', 'date_form_completion'])
        self.providers_df = pd.read_csv(providers_file_path)

    def set_charts_path(self):
        """Create directories for saving charts if they don't exist."""
        os.makedirs(self.charts_path, exist_ok=True)
        os.makedirs(self.charts_provider_path, exist_ok=True)
        os.makedirs(self.charts_group_path, exist_ok=True)

    def merge_and_filter_data(self):
        """
        Merge provider data with the wide data.
        and Filter data based on site, date range, and data quality.
        """
        self.data_df = pd.merge(self.data_df, self.providers_df, on='provider', how='left', suffixes=('', '_from_providers'))
        self.filtered_df = self.data_df[
            (self.data_df['elhs_site_options'] == self.site) &
            (self.data_df['provider'] != 'NA') &
            (self.data_df['provider'].notna()) &
            (self.data_df['date_form_completion'].notna())
            ]

        if self.start_date:
            self.filtered_df = self.filtered_df[(self.filtered_df['date_form_completion'] >= self.start_date)]

        if self.end_date:
            self.filtered_df = self.filtered_df[(self.filtered_df['date_form_completion'] <= self.end_date)]

    def handle_na_proper_name(self):
        """Handle missing proper names by updating them from the provider list."""
        na_proper_name_rows = self.filtered_df['proper_name'].isna()
        unique_providers_with_na = self.filtered_df.loc[na_proper_name_rows, 'provider'].unique()
        if len(unique_providers_with_na) > 0:
            print("Unique providers with NA in 'proper_name':", unique_providers_with_na)
            print("update providers list csv and then try again")
            sys.exit()
        self.filtered_df.loc[na_proper_name_rows, 'proper_name'] = self.filtered_df.loc[na_proper_name_rows, 'provider']

    def aggregate_data(self):
        """
        Convert date columns to datetime and extracting month.
        Aggregate data to calculate completion percentage by month and provider.
        """
        self.filtered_df['date_form_completion'] = pd.to_datetime(self.filtered_df['date_form_completion'])
        self.filtered_df['month'] = self.filtered_df['date_form_completion'].dt.strftime('%Y%m')
        self.agg_df = self.filtered_df.groupby(['month', 'proper_name']).apply(
            lambda x: int((len(x[x['sz_provider_complete'] == 'Y']) / len(x)) * 100)
        ).reset_index(name='complete_pcent')

    def plot_overall_graph(self):
        """Plot an overall completion percentage graph for all providers."""
        plt.figure(figsize=(15, 8))

        for name in self.agg_df['proper_name'].unique():
            subset = self.agg_df[self.agg_df['proper_name'] == name]
            plt.plot('month', 'complete_pcent', data=subset, label=name)

            # Add data labels
            for i, (month, pcent) in enumerate(zip(subset['month'], subset['complete_pcent'])):
                plt.annotate(str(pcent), (month, pcent), textcoords="offset points", xytext=(0, 10), ha='center')

        plt.xlabel('Month')
        plt.ylabel('Complete Percentage')
        plt.title(f'{self.site} Complete % by Providers')
        plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.10), ncol=4)
        plt.subplots_adjust(bottom=0.25)

        plt.savefig(f'{self.charts_path}/{self.site}_all_providers.png')
        plt.close()

    def plot_individual_graphs(self):
        """Plot individual completion percentage graphs for each provider."""
        for provider in self.agg_df['proper_name'].unique():
            provider_df = self.agg_df[self.agg_df['proper_name'] == provider]
            plt.figure(figsize=(10, 6))
            plt.plot('month', 'complete_pcent', data=provider_df, label=provider)

            for i, (month, pcent) in enumerate(zip(provider_df['month'], provider_df['complete_pcent'])):
                plt.annotate(str(pcent), (month, pcent), textcoords="offset points", xytext=(0, 10), ha='center')

            plt.xlabel('Month')
            plt.ylabel('Complete Percentage')
            plt.title(f'Complete % of {provider} - {self.site}')

            plt.savefig(f'{self.charts_provider_path}/{self.site}_{provider}.png')
            plt.close()

    def plot_grouped_graphs(self):
        """Plot grouped completion percentage graphs for providers in batches."""
        unique_providers = self.agg_df['proper_name'].unique()
        total_providers = len(unique_providers)
        total_groups = int(np.ceil(total_providers / self.max_providers_per_chart))
        base_group_size = total_providers // total_groups
        remainder = total_providers % total_groups

        group_sizes = [base_group_size for _ in range(total_groups)]
        for i in range(remainder):
            group_sizes[i] += 1

        start_idx = 0
        group_num = 0

        for group_size in group_sizes:
            group_num += 1
            end_idx = start_idx + group_size
            group_providers = unique_providers[start_idx:end_idx]

            plt.figure(figsize=(15, 8))

            providers_df = self.agg_df[self.agg_df['proper_name'].isin(group_providers)]

            for provider in group_providers:
                subset = providers_df[providers_df['proper_name'] == provider]
                plt.plot('month', 'complete_pcent', data=subset, label=provider)

                for month, pcent in zip(subset['month'], subset['complete_pcent']):
                    plt.annotate(str(pcent), (month, pcent), textcoords="offset points", xytext=(0, 10), ha='center')

            plt.xlabel('Month')
            plt.ylabel('Complete Percentage')
            plt.title(f'{self.site} Complete % by Providers - {group_num} of {len(group_sizes)}')

            plt.legend(loc='upper center', bbox_to_anchor=(0.5, -0.10), ncol=5)
            plt.subplots_adjust(bottom=0.20)

            plt.savefig(f'{self.charts_group_path}/{self.site}_{group_num}_of_{len(group_sizes)}.png')
            plt.close()

            start_idx = end_idx

    def run(self):
        """Run the complete analysis including data loading, filtering, preprocessing, aggregation, and plotting."""
        self.merge_and_filter_data()
        self.handle_na_proper_name()
        self.aggregate_data()
        self.plot_overall_graph()
        self.plot_individual_graphs()
        self.plot_grouped_graphs()


if __name__ == "__main__":
    analyzer = ProvidersCompleteAnalysis(site='MGH_BWH', start_date='2023-01-01', end_date='2023-12-31')
    analyzer.run()
