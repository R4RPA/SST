import os
import numpy as np
import pandas as pd
import glob
import re
from datetime import datetime
import elhs_redcap_code
from logger_master import logger, log_function_entry_exit
import warnings
warnings.filterwarnings("ignore")


@log_function_entry_exit(logger)
class RedCapDataProcessor:
    """
        A data processing class for working with REDCap data.

        This class is designed to load, clean, and transform REDCap data from various sources.
        It processes different forms of data: including demographics, social determinants of health (SDOH),
        patient-reported outcomes (PROs), medications, epilepsy history, visit, seizure frequency data, etc.

        Attributes:
            - user (str): login id of current user logged in to system`.
            - elhs_reg_dict_file (str): Path to the ELHS REDCap data dictionary file.
            - redcap_codebook_file (str): Path to the REDCap codebook file.
            - redcap_downloads (str): Directory where REDCap data downloads are stored.
            - filedate (str): The latest file date extracted from downloaded data files.
            - redcap_data_file_path (str): Path to load main REDCap data file.
            - medication_file_path (str): Path to save medication data file.
            - epilepsy_history_file_path (str): Path to save epilepsy history data file.
            - df_wide_file_path (str): Path to save wide-format data file.

        Methods:
            - get_latest_file_date(): Extracts the latest file date from downloaded data files.
            - load_data(): Loads data from various sources including REDCap data dictionary, REDCap codebook, and REDCap data files.
            - clean_column_name(str_name): Cleans and formats column names.
            - merge_duplicate_columns(df, suffix): Merges duplicate columns in a DataFrame.
            - decode_redcap_data(): Decodes and transforms REDCap data, handling categories and text columns.
`            - process_demographics(): Separates demographic data from the main DataFrame, processes demographic data, including recoding race information.
            - process_sdoh_data(): Processes social determinants of health (SDOH) data.
            - process_patient_reported_outcomes(): Processes patient-reported outcomes (PROs) data.
            - process_visit_data(): Processes visit data.
            - process_history_all(): Processes comprehensive epilepsy history data.
            - process_history(): Processes epilepsy history data.
            - process_seizure_frequency(): Processes seizure frequency data.
            - process_medications(): Processes medication data, including reasons for stopping medications.
            - classify_completion_status(): Classifies completion status for different data forms.
            - calculate_dfwide_variables(): Calculates additional variables for the wide-format DataFrame.
    """
    def __init__(self):
        self.user = os.getenv("LOGNAME")
        self.elhs_reg_dict_file = f"/Users/{self.user}/Dropbox (Partners HealthCare)/ELHS DCC/f. REDCap/ELHS REDCap Instructions & Manuals/1_LONG_ELHSRegistry_DataDictionary_2022-03-28.csv"
        self.redcap_codebook_file = f"/Users/{self.user}/Dropbox (Partners HealthCare)/ELHS DCC/f. REDCap/ELHS REDCap Instructions & Manuals/RedCap_Codebook_v2.xlsx"
        self.redcap_downloads = f"/Users/{self.user}/Dropbox (Partners HealthCare)/ELHS DCC/g. CODING_DASHBOARDS/REDCap Downloads/"
        self.filedate = self.get_latest_file_date()
        self.redcap_data_file_path = os.path.join(self.redcap_downloads, f"redcap_report_all_data_{self.filedate}.csv")
        self.medication_file_path = os.path.join(self.redcap_downloads, f"medication_{self.filedate}.csv")
        self.epilepsy_history_file_path = os.path.join(self.redcap_downloads, f"epilepsy_history_{self.filedate}.csv")
        self.df_wide_file_path = os.path.join(self.redcap_downloads, f"df_wide_{self.filedate}.csv")
        self.load_data()

    def get_latest_file_date(self):
        """
        Retrieves the latest file date from downloaded REDCap files.

        This function scans the REDCap downloads directory for CSV files with names containing date information.
        It extracts the latest date and returns it as a formatted string.

        Returns:
        - Latest file date as a formatted string (e.g., "YYYY_MM_DD").
        """

        files = glob.glob(os.path.join(self.redcap_downloads, "redcap_report_all_data*.csv"))
        max_date = max(
            (datetime.strptime(re.search(r'(\d{4}_\d{2}_\d{2})', os.path.basename(file)).group(1), '%Y_%m_%d').date()
             for file in files), default=None)
        return max_date.strftime('%Y_%m_%d').replace("-", "_") if max_date else None

    def load_data(self):
        """Loads data from various sources including REDCap data dictionary, REDCap codebook, and REDCap data files."""
        self.load_csv_data()
        self.load_excel_data()
        self.load_redcap_data()

    def load_csv_data(self):
        """
        Loads data from the ELHS REDCap data dictionary CSV file, converts column names to lowercase, and cleans them.
        """
        self.dc = pd.read_csv(self.elhs_reg_dict_file, low_memory=False)
        self.dc.columns = [self.clean_column_name(col) for col in self.dc.columns]

    def load_excel_data(self):
        """Loads data from the REDCap codebook Excel file."""
        self.codebook = pd.read_excel(self.redcap_codebook_file, sheet_name='coding', header=0)

    def load_redcap_data(self):
        """Loads data from the main REDCap data CSV file."""
        self.df = pd.read_csv(self.redcap_data_file_path, low_memory=False)

    def clean_column_name(self, str_name):
        """
        Cleans and standardizes column names.
        - Converts to lowercase.
        - Removes special characters.
        - Replaces spaces with underscores.
        """
        str_name = str_name.lower()
        str_name = re.sub(r'[^a-zA-Z0-9\s]', ' ', str_name)
        str_name = ' '.join(str_name.split())
        str_name = str_name.replace(' ', '_')
        return str_name

    def merge_duplicate_columns(self, df, suffix):
        """
        Merges duplicate columns in a DataFrame.
        This function identifies and merges duplicate columns in the given DataFrame by applying a suffix.
        """
        for col in df.columns:
            ref_col = col + suffix
            if ref_col in df.columns:
                mask = df[ref_col].notna()
                df.loc[mask, col] = df.loc[mask, ref_col]
                df.drop(columns=[ref_col], inplace=True)
        df.drop_duplicates(inplace=True)

    def decode_redcap_data(self):
        """
        Decodes and transforms REDCap data.
        This function performs decoding and transformation operations on specific columns in the REDCap data.
        It involves converting data types, encoding categories, and generating text columns based on mappings.
        """
        for column, data_values in elhs_redcap_code.category_mappings.items():
            if isinstance(data_values, list):
                self.df[column] = pd.to_numeric(self.df[column], errors='coerce', downcast='integer')
                self.df[column] = self.df[column].astype('float64').astype('Int64').astype(str).replace('<NA>', np.nan).replace('nan', np.nan)
                self.df[column] = pd.Categorical(self.df[column], categories=data_values, ordered=False)
            elif isinstance(data_values, dict):
                are_keys_integers = all(key.isdigit() for key in data_values.keys())
                if are_keys_integers:
                    self.df[column] = pd.to_numeric(self.df[column], errors='coerce', downcast='integer')
                    self.df[column] = self.df[column].astype('float64').astype('Int64').astype(str).replace('<NA>', np.nan).replace('nan', np.nan)
                self.df[column] = pd.Categorical(self.df[column], categories=list(data_values.keys()), ordered=False)
                self.df[column] = self.df[column].cat.rename_categories(list(data_values.values()))

        for column, data_values in elhs_redcap_code.add_text_columns.items():
            self.df[column + '_text'] = self.df[column].astype('float64').astype('Int64').astype(str).replace(
                data_values).replace(
                {'<NA>': pd.NA, 'nan': pd.NA})

        for column in elhs_redcap_code.date_columns_to_convert:
            self.df[column] = pd.to_datetime(self.df[column], format='%Y-%m-%d')

        self.df['repeat_id'] = self.df['elhs_id'].astype(str) + "_" + self.df['redcap_repeat_instance'].astype('float64').astype('Int64').astype(str)

        self.df['redcap_repeat_instrument'].fillna('demographics', inplace=True)

    def process_demographics(self):
        """
        Separates and processes demographic data.
        Extracts and processes demographic data from the main REDCap data.
        It creates a subset of demographic information and applies various transformations such as race recoding and aggregation.
        It renames columns and filters rows with missing data, creating a demographic form subset.
        """
        self.no_repeat = self.df[self.df['redcap_repeat_instrument'] == 'demographics'].copy()

        def map_race(row):
            for k, v in elhs_redcap_code.race_mapping.items():
                if k in row['race']:
                    return v
            return pd.NA

        self.no_repeat['multi_race'] = self.no_repeat.apply(
            lambda row: "More than 1 Race Reported" if sum(row[elhs_redcap_code.race_cols_to_sum].fillna(0)) > 1 else "1 Race Reported",
            axis=1)

        for col, recode_val in elhs_redcap_code.race_columns_to_recode.items():
            conditions = [self.no_repeat[col] == 1]
            choices = [recode_val]
            self.no_repeat[col] = np.select(conditions, choices, default=self.no_repeat[col].astype('object'))

        self.no_repeat['race'] = self.no_repeat.filter(like='race___').astype(str).agg(
            lambda x: ';'.join(x[~x.isin(['nan', '0.0', ''])]), axis=1)
        self.no_repeat['race_factor'] = self.no_repeat.apply(map_race, axis=1)
        self.no_repeat['race'].replace('', np.nan, inplace=True)

        for column, value in elhs_redcap_code.probarriers_columns_to_update.items():
            self.no_repeat[column] = self.no_repeat[column].apply(lambda x: value if x == 1 else x)

        def join_values(row):
            valid_values = [str(val) for val in row if not pd.isna(val) and val != 0.0]
            return ';'.join(valid_values)

        cols_to_unite = [col for col in self.no_repeat.columns if 'probarriers_identified___' in col]
        self.no_repeat['probarriers_identified'] = self.no_repeat[cols_to_unite].apply(join_values, axis=1)
        self.no_repeat['probarriers_identified'].replace('', np.nan, inplace=True)
        self.no_repeat.drop(columns=cols_to_unite, inplace=True)

        self.dem = self.no_repeat[elhs_redcap_code.demographics_columns].copy()
        self.dem.rename(columns={'date_demographics': 'date_dem'}, inplace=True)
        self.dem = self.dem[~self.dem[elhs_redcap_code.no_na_demographics_columns].isna().all(axis=1)]
        self.dem['dem_form'] = 1

    def process_sdoh_data(self):
        """
        Processes social determinants of health (SDOH) data.
        Identifies and processes SDOH variables based on specific conditions, creating an SDOH form subset.
        Modifies the 'sdoh' attribute to store the processed SDOH data.
        """

        # Identify SDOH variables based on conditions
        cond = self.dc['form_name'] == 'sdoh'
        sdoh_vars = self.dc.loc[cond & self.dc['field_type'].isin(['radio', 'dropdown', 'checkbox']), 'variable_field_name'].tolist()
        sdoh_checkbox_vars = self.dc.loc[cond & (self.dc['field_type'] == 'checkbox'), 'variable_field_name'].tolist()

        # Filter codebook DataFrame by variables
        sdoh_checkbox_codes = self.codebook[self.codebook['variable_field_name'].isin(sdoh_checkbox_vars)].copy()
        sdoh_checkbox_codes['var_name'] = sdoh_checkbox_codes['variable_field_name'] + '___' + sdoh_checkbox_codes['code'].astype(str)
        sdoh_checkbox_codes['val'] = 1

        # Select specific columns from no_repeat
        selected_columns = ['elhs_id'] + [col for col in self.no_repeat.columns if col in sdoh_checkbox_codes['var_name'].tolist()]
        sdoh_checkbox = self.no_repeat[selected_columns].astype(str)

        # Pivot DataFrame to long format
        sdoh_checkbox = pd.melt(sdoh_checkbox, id_vars=['elhs_id'], var_name='var_name', value_name='val')
        sdoh_checkbox['val'] = pd.to_numeric(sdoh_checkbox['val'], errors='coerce')

        # Join with sdoh_checkbox_codes
        cols_to_join = ['var_name', 'val', 'variable_field_name', 'text']
        sdoh_checkbox = pd.merge(sdoh_checkbox, sdoh_checkbox_codes[cols_to_join], on='var_name', how='left', suffixes=('', '_from_med_match'))
        self.merge_duplicate_columns(sdoh_checkbox, '_from_med_match')

        # Unite columns in no_repeat DataFrame based on specific substrings
        def unite_no_repeat_cols(substr):
            cols_to_unite = [col for col in self.no_repeat.columns if substr in col]
            self.no_repeat[substr] = self.no_repeat[cols_to_unite].apply(lambda x: ';'.join(x.dropna().astype(str)), axis=1)
            self.no_repeat.drop(cols_to_unite, axis=1, inplace=True)

        substrings_to_unite = ['needs', 'transport_lack', 'tech_use', 'internet_use']
        for substring in substrings_to_unite:
            unite_no_repeat_cols(substring)

        # Select columns and filter rows
        selected_cols = ['elhs_id', 'patientid', 'date_demographics', 'elhs_site_options']
        existing_cols = set(self.no_repeat.columns)
        sdoh_vars_existing = list(existing_cols.intersection(set(sdoh_vars)))
        selected_cols += sdoh_vars_existing
        sdoh = self.no_repeat[selected_cols]
        self.sdoh = sdoh[sdoh[sdoh_vars_existing].apply(lambda row: row.isna().sum() != len(sdoh_vars_existing), axis=1)]
        self.sdoh['sdoh_form'] = 1

    def process_patient_reported_outcomes(self):
        """
        Processes patient-reported outcomes (PROs) data.\
        This function processes PROs data, renaming columns, and filling missing values from corresponding text columns.
        It creates a PROs form subset.
        """
        pros = self.no_repeat[elhs_redcap_code.pros_columns].copy()

        # Rename columns and filter rows
        pros.rename(columns={'pro_form_completion': 'date_pros'}, inplace=True)
        pros = pros[~pros[elhs_redcap_code.no_na_pros_columns].isna().all(axis=1)]
        pros['pros_form'] = 1

        # Fill missing values (NaN) in a column with values from corresponding text column
        pros['gad7score'] = pd.to_numeric(pros['gad7score'].combine_first(pros['gad7score_text']), errors='coerce')
        pros['pro_phq_score'] = pd.to_numeric(pros['pro_phq_score'].combine_first(pros['phq9score_text']), errors='coerce')
        pros['nddiescore'] = pd.to_numeric(pros['nddiescore'].combine_first(pros['nddiescore_text']), errors='coerce')
        pros['promis10score'] = pd.to_numeric(pros['promis10score'].combine_first(pros['prommis10score_text']), errors='coerce')

        # Drop text columns
        self.pros = pros.drop(columns=['gad7score_text', 'phq9score_text', 'prommis10score_text', 'nddiescore_text'])

    def process_visit_data(self):
        """
        Processes visit data, renaming columns, and adding a unique visit ID.
        It creates an epilepsy visit form subset.
        """
        visit = self.no_repeat[elhs_redcap_code.visit_columns]
        visit = visit.rename(columns={'visit_dt': 'date_epiclinvis'})
        visit['epilepsy_visit_form'] = 1
        visit['tally'] = 1
        visit['visit_id'] = visit.groupby('patientid').cumcount() + 1
        visit['visit_id'] = visit['elhs_id'].astype(str) + "_" + visit['visit_id'].astype('float64').astype('Int64').astype(str)
        self.visit = visit.drop(columns=['tally'])

    def process_history_all(self):
        """Processes comprehensive epilepsy history data, calculates missing values, and stores it in a separate file."""
        history_all = self.no_repeat[elhs_redcap_code.history_all_columns].copy()
        # Calculate the count of columns (excluding the excluded ones)
        count_columns = len(elhs_redcap_code.history_all_columns) - len(elhs_redcap_code.excluded_history_all_columns)
        # Calculate count of missing values for each row
        history_all['empty'] = history_all.drop(columns=elhs_redcap_code.excluded_history_all_columns).isna().sum(axis=1)
        self.history_all = history_all[history_all['empty'] != count_columns]
        self.history_all.to_csv(self.epilepsy_history_file_path, index=False)

    def process_history(self):
        """Processes epilepsy history data, filters rows with missing data, and creates an epilepsy history form subset."""
        history = self.no_repeat[elhs_redcap_code.history_columns].copy()
        history = history[~history[elhs_redcap_code.no_na_history_columns].isna().all(axis=1)]
        history.loc[:, 'epilepsy_history_form'] = 1
        self.history = history

    def process_seizure_frequency(self):
        """
        Processes seizure frequency data, renaming columns, and creating sub-level columns.
        Fills in missing dates for specific sites and flags rows with incomplete data.
        It creates a seizure frequency form subset.
        """

        # Filter and prepare seizure frequency data
        sz = self.df[self.df['redcap_repeat_instrument'].isin(['seizure_frequency', 'Seizure Frequency'])].copy()
        sz = sz[elhs_redcap_code.seiz_freq_columns]
        sz.rename(columns={'date_seizurefreq': 'date_szfreq'}, inplace=True)
        sz['seizure_frequency_form'] = 1

        # Create sub-level columns by combining existing ones
        sz['ilae_epi_sub_level'] = sz[['seizgenilae_text', 'seizfocilae_text', 'seizunkilae_text']].apply(lambda x: '_'.join(x.dropna().astype(str)), axis=1)
        sz.loc[sz['ilae_epi_sub_level'] == '', 'ilae_epi_sub_level'] = float('nan')
        sz['focal_sub_level'] = sz[['focal_w_text', 'focal_wo_text']].apply(lambda x: '_'.join(x.dropna().astype(str)), axis=1)
        sz.loc[sz['focal_sub_level'] == '', 'focal_sub_level'] = float('nan')
        sz.drop(columns=['focal_w_text', 'focal_wo_text'], inplace=True)

        # Merge forms data laterally and handle duplicate/extra columns created on merge
        df_wide = self.dem.merge(self.visit, on=['elhs_id', 'patientid'], how='outer', suffixes=('', '_from_med_match'))
        self.merge_duplicate_columns(df_wide, '_from_med_match')
        df_wide = df_wide.merge(self.pros, on=['elhs_id', 'elhs_site_options'], how='outer', suffixes=('', '_from_med_match'))
        self.merge_duplicate_columns(df_wide, '_from_med_match')
        df_wide = df_wide.merge(self.history, on=['elhs_id'], how='outer', suffixes=('', '_from_med_match'))
        self.merge_duplicate_columns(df_wide, '_from_med_match')
        df_wide = df_wide.merge(sz, on=['elhs_id'], how='outer', suffixes=('', '_from_med_match'))
        self.merge_duplicate_columns(df_wide, '_from_med_match')

        # Fill in missing dates and flag incomplete data
        df_wide['date_pros'] = np.where((df_wide['elhs_site_options'] == 'UC_Health') & df_wide['date_pros'].isna() & ~df_wide['date_dem'].isna() & (df_wide['pros_form'] == 1), df_wide['date_dem'], df_wide['date_pros'])
        df_wide['date_szfreq'] = np.where((df_wide['elhs_site_options'] == 'UC_Health') & df_wide['date_szfreq'].isna() & ~df_wide['date_dem'].isna() & (df_wide['seizure_frequency_form'] == 1), df_wide['date_dem'], df_wide['date_szfreq'])
        df_wide['row_id'] = range(1, len(df_wide) + 1)
        df_wide['missing'] = "Not Missing"
        df_wide.loc[pd.isna(df_wide['patientid']), 'missing'] = "Missing patientid"
        df_wide.loc[pd.isna(df_wide[['repeat_id', 'visit_id', 'pros_form']]).all(axis=1), 'missing'] = "Missing Seizure Frequency and Visit and PROs"
        df_wide.loc[pd.isna(df_wide[elhs_redcap_code.data_wide_key_columns]).all(axis=1), 'missing'] = "Missing All 12 Key Variables"

        self.df_wide = df_wide

    def process_medications(self):
        """
        The process_medications function performs several operations to process medication data.
        It filters the DataFrame to include only medication-related rows,
        handles 'rsnstop' codes and their text mappings, aggregates these into single columns,
        and saves the processed data to a CSV file.
        Then transforms the medication data for merging and combines it into a wide DataFrame.
        """

        # Separate medications (has repeating instruments)
        med = self.df[self.df['redcap_repeat_instrument'].str.lower() == 'medications']
        med = med[elhs_redcap_code.medication_columns + [col for col in self.df.columns if 'rsnstop' in col]]
        med = med.dropna(subset=['asmed'])

        # update 'rsnstop' values
        for col, text in elhs_redcap_code.rsnstop_text_mapping.items():
            new_col = f"rsnstop_text___{col.split('___')[-1]}"
            med[new_col] = med[col].apply(lambda x: text if str(x).replace('.0', '') == '1' else None)

        for col, text in elhs_redcap_code.rsnstop_mapping.items():
            med[col] = med[col].apply(lambda x: text if str(x).replace('.0', '') == '1' else None)

        rsnstop_cols = [col for col in med.columns if 'rsnstop___' in col]
        rsnstop_text_cols = [col for col in med.columns if 'rsnstop_text' in col]

        # merge rsnstop columns into 'rsnstop' and 'rsnstop_text' columns
        med['rsnstop'] = med.filter(like='rsnstop___').apply(
            lambda x: ';'.join(str(val).replace('.0', '') for val in x if pd.notna(val) and val != '') if any(
                pd.notna(x) & (x != '')) else '', axis=1)
        med['rsnstop_text'] = med.filter(like='rsnstop_text___').apply(
            lambda x: ';'.join(str(val) for val in x if pd.notna(val) and val != '') if any(
                pd.notna(x) & (x != '')) else '', axis=1)

        med['rsnstop'] = med['rsnstop'].apply(lambda x: None if x == '' else x)
        med['rsnstop_text'] = med['rsnstop_text'].apply(lambda x: None if x == '' else x)
        med.drop(columns=rsnstop_cols + rsnstop_text_cols, inplace=True)

        # Save medication file
        med.to_csv(self.medication_file_path, index=False)

        # Select med form and rsnstop columns
        med = med[['elhs_id', 'med_form_compl', 'redcap_repeat_instance', 'asmed', 'rsnstop', 'rsnstop_text', 'indic']]
        med.rename(columns={'med_form_compl': 'date_med_form'}, inplace=True)
        med['tally'] = 1
        med['elhs_id'] = med['elhs_id'].fillna("NA")
        med['date_med_form'] = med['date_med_form'].fillna("NA")

        # Pivot the DataFrame to long format for easier processing.
        med['redcap_repeat_instance'] = med.groupby(['elhs_id', 'date_med_form'])['tally'].cumsum()
        med = pd.melt(med, id_vars=['elhs_id', 'date_med_form', 'redcap_repeat_instance'], value_vars=['asmed', 'rsnstop', 'rsnstop_text', 'indic'])
        med.rename(columns={'variable': 'var'}, inplace=True)
        med['var'] = med['var'].apply(lambda x: str(x)[:-2] if str(x).endswith('.0') else x)
        med['var'] = med['var'] + "_" + med['redcap_repeat_instance'].astype(str)
        med = med.dropna(subset=['value'])
        med = med[['elhs_id', 'date_med_form', 'var', 'value']]
        med = med.pivot_table(index=['elhs_id', 'date_med_form'], columns='var', values='value', aggfunc='first').reset_index()
        med['med_form'] = 1

        # Merge data and add counts
        med = med.merge(self.dem[['patientid', 'elhs_id', 'elhs_site_options']], on='elhs_id', how='left', suffixes=('', '_from_med_match'))
        self.merge_duplicate_columns(med, '_from_med_match')

        unique_groups = med.sort_values(['elhs_id', 'patientid']).drop_duplicates(subset=['elhs_id', 'patientid'])
        unique_groups['med_form_id'] = range(1, len(unique_groups) + 1)

        # Map 'med_form_id' back to the original DataFrame
        med = pd.merge(med, unique_groups[['elhs_id', 'patientid', 'med_form_id']], on=['elhs_id', 'patientid'], how='left')
        med.columns = [col[:-2] if col.endswith('.0') or col.endswith('_x') else col for col in med.columns]

        med_forms_dates = med[['patientid', 'elhs_id', 'elhs_site_options', 'date_med_form']].drop_duplicates()
        med_forms_dates['med_form_count'] = 1
        med_forms_dates = med_forms_dates.sort_values(['elhs_id', 'date_med_form'])
        med_forms_dates['med_form_count'] = med_forms_dates.groupby('elhs_id')['med_form_count'].cumsum()
        multiple_dates_sites = med_forms_dates[med_forms_dates['med_form_count'] > 1]['elhs_site_options'].dropna().unique()


        # Get seizure frequency, pro, and visit dates
        sz_single_row = self.df_wide[['elhs_id', 'date_pros', 'date_epiclinvis', 'date_szfreq', 'repeat_id', 'row_id']]
        sz_single_row = sz_single_row.drop_duplicates().reset_index(drop=True)

        sz_single_row['date'] = sz_single_row['date_szfreq'].combine_first(
            sz_single_row['date_epiclinvis']).combine_first(sz_single_row['date_pros'])
        sz_single_row['date'] = pd.to_datetime(sz_single_row['date'], format='%Y-%m-%d')

        # Add Visit ID
        sz_single_row['new_visit_id'] = sz_single_row.groupby('elhs_id').cumcount() + 1
        sz_single_row['sf_visit_id'] = sz_single_row['elhs_id'].astype(str) + "__" + sz_single_row[
            'new_visit_id'].astype(str)

        # Merge medications with seizure frequency data, matching by date
        sz_match = sz_single_row[['elhs_id', 'sf_visit_id', 'date_szfreq', 'date', 'row_id']]

        # Filter medications
        med_site_data = med[med['elhs_site_options'].isin(multiple_dates_sites)]
        med_match = med_site_data.drop_duplicates(subset=['elhs_site_options', 'elhs_id', 'date_med_form'])
        med_match = pd.merge(med_match, sz_match, on='elhs_id', how='left', suffixes=('', '_from_med_match'))
        self.merge_duplicate_columns(med_match, '_from_med_match')

        med_match['date_match'] = (med_match['date'] == med_match['date_med_form']).astype(int)
        med_match['sf_visit_id'] = med_match.apply(
            lambda row: str(row['sf_visit_id']) if pd.notna(row['sf_visit_id']) else str(row['elhs_id']), axis=1)
        med_match = med_match.sort_values(by=['sf_visit_id', 'date_match'], ascending=[True, False])
        med_match['row_number'] = med_match.groupby('sf_visit_id').cumcount() + 1
        med_match = med_match[med_match['row_number'] == 1]

        med_match_id = med_match[['elhs_id', 'date_med_form', 'sf_visit_id']]
        sf_match_id = med_match[['elhs_id', 'row_id', 'sf_visit_id']]

        # Add medications to df_wide
        self.med = pd.merge(med_match_id, med, how='left', suffixes=('', '_from_med_match'))
        self.merge_duplicate_columns(self.med, '_from_med_match')

        self.df_wide = pd.merge(self.df_wide, sf_match_id, how='left', suffixes=('', '_from_sf_match'))
        self.merge_duplicate_columns(self.df_wide, '_from_sf_match')

        self.df_wide = pd.merge(self.df_wide, self.med, how='outer', suffixes=('', '_from_med'))
        self.merge_duplicate_columns(self.df_wide, '_from_med')

    def process_medications_old(self):


        # Filter DataFrame for medication data
        med = self.df[self.df['redcap_repeat_instrument'].str.lower() == 'medications']
        med = med[elhs_redcap_code.medication_columns + [col for col in self.df.columns if 'rsnstop' in col]]
        med = med.dropna(subset=['asmed'])

        # Handle 'rsnstop' codes and text mappings
        for col, text in elhs_redcap_code.rsnstop_text_mapping.items():
            new_col = f"rsnstop_text___{col.split('___')[-1]}"
            med[new_col] = med[col].apply(lambda x: text if str(x).replace('.0', '') == '1' else None)

        for col, text in elhs_redcap_code.rsnstop_mapping.items():
            med[col] = med[col].apply(lambda x: text if str(x).replace('.0', '') == '1' else None)

        # Aggregate 'rsnstop' and 'rsnstop_text' into single columns
        rsnstop_cols = [col for col in med.columns if 'rsnstop___' in col]
        rsnstop_text_cols = [col for col in med.columns if 'rsnstop_text' in col]
        med['rsnstop'] = med.filter(like='rsnstop___').apply(lambda x: ';'.join(str(val).replace('.0', '') for val in x if pd.notna(val) and val != '') if any(pd.notna(x) & (x != '')) else '', axis=1)
        med['rsnstop_text'] = med.filter(like='rsnstop_text___').apply(lambda x: ';'.join(str(val) for val in x if pd.notna(val) and val != '') if any(pd.notna(x) & (x != '')) else '', axis=1)
        med['rsnstop'] = med['rsnstop'].apply(lambda x: None if x == '' else x)
        med['rsnstop_text'] = med['rsnstop_text'].apply(lambda x: None if x == '' else x)
        med.drop(columns=rsnstop_cols + rsnstop_text_cols, inplace=True)

        # Save processed medication data to CSV
        med.to_csv(self.medication_file_path, index=False)

        # Transform medication data for merging
        med = med[['elhs_id', 'med_form_compl', 'redcap_repeat_instance', 'asmed', 'rsnstop', 'rsnstop_text', 'indic']]
        med.rename(columns={'med_form_compl': 'date_med_form'}, inplace=True)
        med['tally'] = 1
        med['elhs_id'] = med['elhs_id'].fillna("NA")
        med['date_med_form'] = med['date_med_form'].fillna("NA")
        med['redcap_repeat_instance'] = med.groupby(['elhs_id', 'date_med_form'])['tally'].cumsum()
        med = pd.melt(med, id_vars=['elhs_id', 'date_med_form', 'redcap_repeat_instance'], value_vars=['asmed', 'rsnstop', 'rsnstop_text', 'indic'])
        med.rename(columns={'variable': 'var'}, inplace=True)
        med['var'] = med['var'].apply(lambda x: str(x)[:-2] if str(x).endswith('.0') else x)
        med['var'] = med['var'] + "_" + med['redcap_repeat_instance'].astype(str)
        med = med.dropna(subset=['value'])
        med = med[['elhs_id', 'date_med_form', 'var', 'value']]
        med = med.pivot_table(index=['elhs_id', 'date_med_form'], columns='var', values='value', aggfunc='first').reset_index()
        med['med_form'] = 1

        # Merge transformed medication data into df_wide
        med = med.merge(self.df[['patientid', 'elhs_id', 'elhs_site_options']], on='elhs_id', how='left', suffixes=('', '_from_med_match'))
        self.merge_duplicate_columns(med, '_from_med_match')
        unique_groups = med.sort_values(['elhs_id', 'patientid']).drop_duplicates(subset=['elhs_id', 'patientid'])
        unique_groups['med_form_id'] = range(1, len(unique_groups) + 1)
        med = pd.merge(med, unique_groups[['elhs_id', 'patientid', 'med_form_id']], on=['elhs_id', 'patientid'], how='left')
        med.columns = [col[:-2] if col.endswith('.0') or col.endswith('_x') else col for col in med.columns]
        self.df_wide = self.df_wide.merge(med, how='outer', suffixes=('', '_from_med'))
        self.merge_duplicate_columns(self.df_wide, '_from_med')

        self.med = med

    def classify_completion_status(self):
        """
        Classifies completion status of forms.
        It classifies completion status for patient and provider forms and
            for various forms related to seizure frequency, adherence barriers, and medication existence.
        It generates 'complete' columns based on the presence of specific data.
        """

        # Classify completion status for Seizure frequency forms
        self.df_wide['sz_patient_complete'] = np.where(self.df_wide['prosflastseiz'].notna() | self.df_wide['prosftypicalseiz'].notna(), 'Y', 'N')
        self.df_wide['sz_provider_complete'] = np.where(self.df_wide['seizilae'].notna() & (self.df_wide['seizfreq'].notna() | self.df_wide['freqlastseizdate'].notna()), 'Y', 'N')
        self.df_wide['sz_complete'] = np.where((self.df_wide['sz_patient_complete'] == 'Y') | (self.df_wide['sz_provider_complete'] == 'Y'), 'Y', 'N')

        # Classify completion status for Adherence Barriers forms
        self.df_wide['adb_pro_complete'] = np.where(self.df_wide['probarriers_identified'].notna(), 'Y', 'N')
        self.df_wide['adb_ecv_complete'] = np.where(self.df_wide['medadhchecklist'].notna(), 'Y', 'N')
        self.df_wide['adb_complete'] = np.where((self.df_wide['adb_pro_complete'] == 'Y') | (self.df_wide['adb_ecv_complete'] == 'Y'), 'Y', 'N')

        # Classify completion status for Medication existence
        self.df_wide['med_exists'] = np.where(self.df_wide['asmed_1'].notna(), 'Y', 'N')

    def calculate_dfwide_variables(self):
        """
        Calculates additional variables in the wide-format DataFrame.
        This function calculates additional variables such as age, age category, and form completion dates.
        It also handles missing or inconsistent age values.
        """

        # Calculate the date of form completion
        self.df_wide['date_form_completion'] = self.df_wide[['date_szfreq', 'date_pros', 'date_epiclinvis']].max(axis=1, skipna=True)
        self.df_wide['date_form_completion'] = np.where(self.df_wide['date_form_completion'].isna(),  self.df_wide['date_dem'], self.df_wide['date_form_completion'])

        # Calculate the week ending day and week number
        self.df_wide['date_week_end_day'] = (self.df_wide['date_form_completion'] + pd.offsets.Week(weekday=6))
        self.df_wide['date_week_number'] = self.df_wide['date_form_completion'].dt.strftime('%Y-W%U')

        # Standardize and calculate age
        self.df_wide['subject_age'] = pd.to_numeric(self.df_wide['subject_age'], errors='coerce')
        self.df_wide['subject_dob'] = pd.to_datetime(self.df_wide['subject_dob'])
        self.df_wide['date_epiclinvis'] = pd.to_datetime(self.df_wide['date_epiclinvis'])
        self.df_wide['age'] = pd.to_numeric(self.df_wide['age'], errors='coerce')

        def calculate_age(row):
            if not pd.isna(row['subject_age']):
                return row['subject_age']
            elif not pd.isna(row['subject_dob']):
                return (row['date_epiclinvis'] - row['subject_dob']).days // 365
            else:
                return row['age']

        self.df_wide['age_calculated'] = self.df_wide.apply(calculate_age, axis=1)
        self.df_wide.loc[self.df_wide['age_calculated'] > 120, 'age_calculated'] = np.nan
        self.df_wide.loc[self.df_wide['age_calculated'] < 0, 'age_calculated'] = np.nan
        self.df_wide.loc[(self.df_wide['age_calculated'] < 1) & (self.df_wide['elhs_site_options'] == 'MGH_BWH'), 'age_calculated'] = np.nan

        # Segment age into specified age ranges
        self.df_wide['age_category'] = pd.cut(self.df_wide['age_calculated'], bins=elhs_redcap_code.bin_edges, labels=elhs_redcap_code.bin_labels, right=True)
        self.df_wide['age_category'] = self.df_wide['age_category'].astype('category')
        self.df_wide['age_category'] = self.df_wide['age_category'].cat.reorder_categories(elhs_redcap_code.bin_labels, ordered=True)
        self.df_wide['patientid'] = self.df_wide['patientid'].astype(str)

    def save_df_wide_to_csv(self):
        """Saves the wide-format DataFrame containing processed data to a CSV file."""
        self.df_wide.to_csv(self.df_wide_file_path, index=False)

    def run(self):
        """
        Executes the complete data processing pipeline.

        This function orchestrates the complete data processing pipeline, including decoding RedCap data, processing
        demographic information, social determinants of health (SDOH) data, patient-reported outcomes (PROs), visit data,
        history data, seizure frequency data, medications data, classification of completion status, calculation of
        wide-format variables, and saving the processed data to a CSV file.

        Each step of the pipeline is executed in sequence, and the resulting wide-format DataFrame is saved to a CSV file.
        """

        # Execute each step of the data processing pipeline
        self.decode_redcap_data()  # Decode RedCap data using category mappings and text columns
        self.process_demographics()  # Process demographic information
        self.process_sdoh_data()  # Process social determinants of health (SDOH) data
        self.process_patient_reported_outcomes()  # Process patient-reported outcomes (PROs)
        self.process_visit_data()  # Process visit data
        self.process_history_all()  # Process all history data
        self.process_history()  # Process history data
        self.process_seizure_frequency()  # Process seizure frequency data
        self.process_medications()  # Process medications data
        self.classify_completion_status()  # Classify completion status based on data availability
        self.calculate_dfwide_variables()  # Calculate wide-format variables
        self.save_df_wide_to_csv()  # Save the processed data to a CSV file


def process_redcap_data():
    # Initialize an instance of the RedCapDataProcessor
    redcap = RedCapDataProcessor()
    # Execute the complete data processing pipeline
    redcap.run()


if __name__ == "__main__":
    # Entry point to start data processing when the script is executed
    process_redcap_data()
