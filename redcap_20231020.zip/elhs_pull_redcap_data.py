import csv
import os
import pandas as pd
import requests
from datetime import date
import hashlib
from io import StringIO
import elhs_redcap_code
from logger_master import logger, log_function_entry_exit
import warnings
warnings.filterwarnings("ignore")


@log_function_entry_exit(logger)
class PullRedCapData:
    """
    Automates the process of fetching, transforming, and storing data
    from a RedCap instance. It handles API interactions, data de-identification,
    and stores processed data in CSV formats.
    """

    def __init__(self):
        """Initialize instance variables and read the API token."""
        self.filedate = date.today().strftime("%Y_%m_%d")
        self.user = os.getenv("LOGNAME")
        self.download_path = f"/Users/{self.user}/Dropbox (Partners HealthCare)/ELHS DCC/g. CODING_DASHBOARDS/"
        self.token = self.read_token_from_file()
        self.df = None

    def read_token_from_file(self):
        """Read the API token from a file."""
        token_path = os.path.join(self.download_path, "Data Download/token.txt")
        with open(token_path, 'r') as f:
            return f.read().strip()

    def fetch_data_from_redcap(self):
        """Fetch data from RedCap API and store it in a DataFrame."""
        # Set up payload for API request
        payload = {
            'token': self.token,
            'content': 'report',
            'format': 'csv',
            'report_id': '120440',
            'csvDelimiter': ',',
            'rawOrLabel': 'raw',
            'rawOrLabelHeaders': 'raw',
            'exportCheckboxLabel': 'false',
            'returnFormat': 'csv'
        }
        # Make the API request
        url = "https://redcap.partners.org/redcap/api/"
        response = requests.post(url, data=payload)
        csv_data = response.text
        self.df = pd.read_csv(StringIO(csv_data), parse_dates=redcap_code.date_columns)

    def hash_unique_id(self, unique_id):
        """Hash a unique identifier using SHA-256."""
        return hashlib.sha256(unique_id.encode()).hexdigest()

    def save_df(self, df, filename):
        """Save DataFrame to a CSV file."""
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        df.to_csv(filename, index=False, header=True, mode='w', sep=',', quoting=csv.QUOTE_NONNUMERIC)

    def transform_and_save_data(self):
        """Transform the data and save it as csv formats."""

        # Typecasting and de-identifying data
        df_deids = self.df[['elhs_id', 'elhs_site_options', 'mrn']].drop_duplicates().dropna(subset=['mrn'])
        df_deids['unique_id'] = df_deids['elhs_site_options'].astype(str) + df_deids['mrn'].astype(str)
        df_deids['patientid'] = df_deids['unique_id'].apply(self.hash_unique_id)

        # Save de-identified data
        deids_filename = os.path.join(self.download_path, f"REDCap Downloads/patientid_lookup_{self.filedate}.csv")
        self.save_df(df_deids, deids_filename)

        # Merge and drop sensitive columns
        self.df = pd.merge(self.df, df_deids, how='left', on=['elhs_id', 'elhs_site_options', 'mrn'])
        self.df.drop(columns=['mrn'], inplace=True)

        # Save transformed data
        redcap_filename = os.path.join(self.download_path, f"REDCap Downloads/redcap_report_all_data_{self.filedate}.csv")
        self.save_df(self.df, redcap_filename)

    def run(self):
        """Main orchestrator function to fetch, transform, and save data."""
        self.fetch_data_from_redcap()
        self.transform_and_save_data()


def extract_redcap_data():
    # Initialize an instance of the PullRedCapData
    pullredcap = PullRedCapData()
    # Execute the data extraction pipeline
    pullredcap.run()


if __name__ == "__main__":
    # Entry point to start data extraction when the script is executed
    extract_redcap_data()
