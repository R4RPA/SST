date_columns = ['pro_form_completion', 'history_completion_date', 'visit_dt', 'form_completion_date', 'date_seizurefreq', 'med_form_compl', 'stdate', 'enddate', 'first_contact_date']

category_mappings = {
    'dem_sex': {'1': 'Male', '2': 'Female', '3': 'Other'},
    'gndident': {'1': 'Man', '2': 'Woman', '3': 'Gender non-conforming', '4': 'Gender-queer', '5': 'Trans man',
                 '6': 'Trans woman', '7': 'Other', '0': 'I choose not to answer'},
    'ethnic': {'1': 'Hispanic or Latino', '2': 'Not Hispanic or Latino', '0': 'I choose not to answer'},
    'mar_statsdoh': {'1': 'Married/Domestic partner', '2': 'Widowed', '3': 'Legally separated',
                     '4': 'Single (never married)', '5': 'Divorced/Annulled', '6': 'Committed/Long-Term Relationship',
                     '7': 'Other, specify', '0': 'I choose not to answer'},
    'live': {'1': 'Yes', '2': 'No', '0': 'I choose not to answer'},
    'live_specify___1': ['0', '1'],
    'live_specify___2': ['0', '1'],
    'live_specify___3': ['0', '1'],
    'live_specify___0': ['0', '1'],
    'housing': {'1': 'I have stable housing', '2': 'I have housing but I am worried about losing it',
                '3': 'I do not have housing', '0': 'I choose not to answer'},
    'housing_specify': {'1': 'House or condo, owned', '2': 'Apartment or condo, rented', '3': 'Mobile home',
                        '4': 'Single room', '5': 'Other (specify)'},
    'housing_other': {'1': 'Senior independent living', '2': 'Assisted living facility',
                      '3': 'Nursing home or rehab, temporary Nursing home or rehab, permanent',
                      '4': 'Group setting (specify)'},
    'housing_grp': {'1': 'Dormitory', '2': 'Group home', '3': 'Sober living house', '4': 'Health care facility',
                    '5': 'Incarcerated', '0': 'I choose not to answer', '6': 'Other (Specify)'},
    'educationsdoh': {'1': '1st Grade', '2': '2nd Grade', '3': '3rd Grade', '4': '4th Grade', '5': '5th Grade',
                      '6': '6th Grade', '7': '7th Grade', '8': '8th Grade', '9': '9th Grade', '10': '10th Grade',
                      '11': '11th Grade', '12': '12th Grade', '13': 'High School Graduate', '14': 'GED or equivalent',
                      '15': 'Some college, no degree', '16': 'Associate Degree, academic program',
                      '17': 'Bachelors Degree (e.g., BA, AB, BS, BBA)',
                      '18': 'Masters Degree (e.g., MA, S, MEng, Med, MBA)',
                      '19': 'Professional School Degree (e.g., MD, DDS, DVM, JD)',
                      '20': 'Doctoral Degree (e.g., PhD, EdD)', '21': 'Never attended/kindergarten only',
                      '0': 'Unknown'},
    'job': {'1': 'Unemployed', '2': 'Working, full time (more than 35 hours per week)',
            '3': 'Working, part time (less than 35 hours per week)', '4': 'Student', '5': 'Active military',
            '6': 'Keeping house', '7': 'Not employed, looking for work', '8': 'Not employed, not looking for work',
            '9': 'Temporarily laid off', '10': 'Sick leave or maternity leave', '11': 'Retired',
            '12': 'Disabled, temporarily', '13': 'Disabled, permanently',
            '14': 'Volunteer at least 4 hours per week (without pay)', '15': 'Other [specify)',
            '0': 'I choose not to answer'},
    'live_safe': {'1': 'Yes', '2': 'No', '0': 'I choose not to answer'},
    'needs___1': ['0', '1'],
    'needs___2': ['0', '1'],
    'needs___3': ['0', '1'],
    'needs___4': ['0', '1'],
    'needs___5': ['0', '1'],
    'needs___6': ['0', '1'],
    'needs___7': ['0', '1'],
    'needs___8': ['0', '1'],
    'needs___9': ['0', '1'],
    'needs___0': ['0', '1'],
    'transport_lack___1': ['0', '1'],
    'transport_lack___2': ['0', '1'],
    'transport_lack___3': ['0', '1'],
    'transport_lack___0': ['0', '1'],
    'insurance': {'1': 'None/uninsured', '2': 'Medicaid or other government plan', '3': 'Medicare',
                  '4': 'TRICARE or other military health care', '5': 'Veterans Affairs', '6': 'Indian Health Service',
                  '7': 'Other public insurance',
                  '8': 'Private insurance, through a current or former employer of patient or other family member [specify]',
                  '9': 'Private insurance, purchased directly from insurance company or exchange by patient or other family member [specify]',
                  '10': 'Other [specify]:', '0': 'I choose not to answer'},
    'detention': {'1': 'Yes', '2': 'No', '3': 'I choose not to answer'},
    'domestic_vl': {'1': 'Yes', '2': 'No', '3': 'I choose not to answer'},
    'social': {'1': 'Less than once a week', '2': '1 or 2 times a week', '3': '3-5 times a week',
               '4': '5 or more times a week', '0': 'I choose not to answer'},
    'stress': {'1': 'Not at all', '2': 'A little bit', '3': 'Somewhat', '4': 'Very much',
               '0': 'I choose not to answer'},
    'refugee': {'1': 'Yes', '2': 'No', '3': 'I choose not to answer'},
    'migrant_income': {'1': 'Yes', '2': 'No', '0': 'I choose not to answer'},
    'army_dischrge': {'1': 'Yes', '2': 'No', '0': 'I choose not to answer'},
    'sexual_ornt': {'1': 'Straight or heterosexual', '2': 'Lesbian, gay, or homosexual', '3': 'Bisexual',
                    '4': 'Other [specify]', '0': 'I choose not to answer'},
    'income': {'1': 'Less than $24,999', '2': ' $25,000-$49,999', '3': '$50,000 or greater',
               '0': 'I choose not to answer'},
    'read': {'1': 'Good', '2': 'Average', '3': 'Poor', '0': 'I choose not to answer'},
    'read2': {'1': 'Always', '2': 'Sometimes', '3': 'Never', '0': 'I choose not to answer'},
    'tech_use___1': ['0', '1'],
    'tech_use___2': ['0', '1'],
    'tech_use___3': ['0', '1'],
    'tech_use___4': ['0', '1'],
    'tech_use___5': ['0', '1'],
    'tech_use___0': ['0', '1'],
    'internet_use___1': ['0', '1'],
    'internet_use___2': ['0', '1'],
    'internet_use___3': ['0', '1'],
    'internet_use___4': ['0', '1'],
    'internet_use___5': ['0', '1'],
    'internet_use___0': ['0', '1'],
    'sdoh_complete': {'0': 'Incomplete', '1': 'Unverified', '2': 'Complete'},

    'prosflastseiz': {'TOD': 'Today',
                      '1DAY': 'More than 1 day to 6 days ago',
                      '1WK': 'More than 1 week to 4 weeks ago',
                      '5WK': 'More than 1 month to 3 months ago',
                      '13WK': 'More than 3 months to 6 months ago',
                      '6MON': 'More than 6 months to 12 months ago',
                      '1YR': 'More than 1 year to 2 years ago',
                      '2YR': 'More than 2 years ago',
                      'DCL': 'Decline to answer',
                      'IDK': 'I dont know'},
    'medadhchecklist': {'Y': 'Yes', 'N': 'No', 'UN': 'Unknown'},
    'seizreportby': {'1': 'Patient', '2': 'Caregiver', '3': 'Parent/LAR'},
    'freqseizdiag': {'POSS': 'Possible = the summary of evidence suggests less than 50% confidence level',
                     'PROB': 'Probable = the summary of evidence suggests greater than 50% confidence level',
                     'DEF': 'Definite = the summary of evidence suggests 100% confidence level',
                     'UNK': 'Unknown = the summary of evidence is not sufficient to support a finding',
                     'NA': 'Not Applicable'},
    'seizure_frequency_complete': {'0': 'Incomplete', '1': 'Unverified', '2': 'Complete'},
    'ongoing': {'Y': 'Yes', 'N': 'No', 'UNK': 'Unknown'},
    'unit': {'MG': 'mg (milligram)', 'MCG': 'mcg (microgram)', 'G': 'g (gram)', 'ML': 'mL (milliliter)',
             'CL': 'cL (centiliter)', 'DR': 'dr (dram)', 'GR': 'gr (grain)', 'GTT': '(gtt, drop)',
             'IU': '(IU, international unit)', 'L': 'L (liter)', 'MCL': 'mcL (microliter)', 'OZ': 'oz (ounce)',
             'SPY': 'spy (spray/squirt)', 'TBSP': 'tbsp (tablespoon)', 'TSP': 'tsp (teaspoon)', 'OTH': 'Other'},
    'freq': {'QD': 'once a day (QD)', 'BID': 'twice a day (BID)', 'TID': 'three times a day (TID)',
             'QID': 'four times a day (QID)', 'QOD': 'every other day (QOD)', 'QW': 'every week (QW)',
             'BIW': 'twice a week (BIW)', 'QM': 'every month (QM)', 'PRN': 'as needed (PRN)', 'OTH': 'Other',
             'UNK': 'Unknown'},
    'route': {'ORAL': 'Oral', 'BUCC': 'Buccal', 'EPID': 'Epidural', 'INTDER': 'Intradermal', 'INHAL': 'Inhalation',
              'INTLES': 'Intralesion', 'INTMUS': 'Intramuscular', 'INTOC': 'Intraocular', 'INTPER': 'Intraperitoneal',
              'INTTHE': 'Intrathecal', 'NG': 'Nasogastric or PEG', 'NASAL': 'Nasal', 'RECT': 'Rectal',
              'SUBC': 'Subcutaneous', 'TOP': 'Topical', 'SUBLIN': 'Sublingual', 'TRANS': 'Transdermal', 'OTH': 'Other',
              'UNK': 'Unknown'},
    'form': {'BRAND': 'Brand', 'GEN': 'Generic', 'UNK': 'Unknown'},
    'indic': {'EPI': 'Epilepsy', 'ANX': 'Anxiety disorder', 'ADD': 'Attention deficit disorder',
              'CONTRA': 'Contraception', 'DEM': 'Dementia', 'DEP': 'Depression', 'DIAB': 'Diabetes',
              'INSOM': 'Insomnia', 'MIG': 'Migraine headache', 'HEAD': 'Headache (non-migraine)',
              'HYLIP': 'Hyperlipidemia', 'HYTEN': 'Hypertension', 'PAIN': 'Pain (non-headache)', 'PSYCH': 'Psychosis',
              'SLEEP': 'Sleep disorder', 'STROKE': 'Stroke prevention', 'OTH': 'Other', 'UNK': 'Unknown'},
    'rescue': {'Y': 'Yes', 'N': 'No', 'UNK': 'Unknown'},
    'medications_complete': {'0': 'Incomplete', '1': 'Unverified', '2': 'Complete'},

}


add_text_columns = {
    'freqlastseizdate': {'1': 'Today', '2': 'More than 1 day to 6 days ago',
                              '3': 'More than 1 week to 4 weeks ago', '4': 'More than 1 month to 3 months ago',
                              '5': 'More than 3 months to 6 months ago', '6': 'More than 6 months to 12 months ago',
                              '7': 'More than 1 year to 2 years ago', '8': 'More than 2 years ago',
                              '9': 'Decline to answer', '0': 'Unknown'},
    'seizfreq': {'2': 'Innumerable (≥10 per day on most days)',
                      '3': 'Multiple per day (i.e., 4 days per week with ≥2 seizures)',
                      '4': 'Daily (i.e., 4 or more days in the past week)',
                      '5': 'Weekly but not daily (i.e., 1 - 3 in the past week)',
                      '6': 'Monthly but not weekly (i.e., 1 - 3 in the past month)',
                      '7': 'At least once per year, but not every month (i.e., 10 or fewer in past 12 months)',
                      '8': 'Less than once per year', '1': 'Frequency not well defined', '0': 'Unknown'},
    'seizilae': {'1': 'Epileptic Seizures', '2': 'Non-Epileptic Events or Uncertain Events'},
    'seizilae_epi': {'1': 'Generalized', '2': 'Focal', '3': 'Unknown Onset'},
    'seizilae_nonepi': {'1': 'Non-epileptic Events - Psychogenic', '2': 'Non-epileptic Events - Physiologic',
                             '3': 'Unclassified Event - Unsure if epileptic or not'},
    'seizgenilae': {'0': 'Absence, atypical', '1': 'Absence, typical', '2': 'Atonic', '3': 'Clonic',
                         '4': 'Epileptic spasms', '5': 'Eyelid myoclonia', '6': 'Myoclonic', '7': 'Myoclonic absence',
                         '8': 'Myoclonic atonic', '9': 'Myoclonic-tonic-clonic', '10': 'Tonic', '11': 'Tonic-clonic'},
    'seizfocilae': {'1': 'Focal aware, without impairment of consciousness',
                         '2': 'Focal with impairment of consciousness', '3': 'Focal to bilateral tonic-clonic'},
    'focal_wo': {'1': 'With observable motor components',
                      '2': 'Involving subjective sensory or psychic phenomena only'},
    'focal_w': {'1': 'Motor (automatisms, atonic, clonic, epileptic spasms, hyperkinetic, myoclonic, tonic)',
                     '2': 'Non-motor (autonomic, behavior arrest, cognitive, emotional, sensory)'},
    'seizunkilae': {'0': 'Unknown Onset, Non-motor', '1': 'Unknown Onset Motor tonic-clonic',
                         '2': 'Unknown Onset, Other motor', '3': 'Unknown Onset, Epileptic Spasms'},
}

date_columns_to_convert = ['date_demographics', 'date_seizurefreq', 'subject_dob', 'history_completion_date', 'form_completion_date','pro_form_completion', 'med_form_compl', 'visit_dt']

race_cols_to_sum = ['race___race_ind', 'race___race_asi', 'race___race_afr', 'race___race_haw', 'race___race_whi']

race_mapping = {
    'RACE_IND': 'American Indian or Alaskan Native',
    'RACE_ASI': 'Asian',
    'RACE_AFR': 'Black or Afr. American',
    'RACE_HAW': 'Native Hawaiian or Other Pacific Islander',
    'RACE_WHI': 'White',
    'RACE_OTH': 'Other',
    'RACE_REP': 'I choose not to answer',
    'RACE_UNK': 'Unknown'
}

race_columns_to_recode = {
    'race___race_ind': 'RACE_IND',
    'race___race_asi': 'RACE_ASI',
    'race___race_afr': 'RACE_AFR',
    'race___race_haw': 'RACE_HAW',
    'race___race_whi': 'RACE_WHI',
    'race___race_oth': 'RACE_OTH',
    'race___race_rep': 'RACE_REP',
    'race___race_unk': 'RACE_UNK'
}

probarriers_columns_to_update = {
    'probarriers_identified___remember': "REMEMBER",
    'probarriers_identified___taste': "TASTE",
    'probarriers_identified___swallow': "SWALLOW",
    'probarriers_identified___sideff': "SIDEFF",
    'probarriers_identified___secret': "SECRET",
    'probarriers_identified___noneed': "NONEED",
    'probarriers_identified___toomany': "TOOMANY",
    'probarriers_identified___nohelp': "NOHELP",
    'probarriers_identified___runout': "RUNOUT",
    'probarriers_identified___confuse': "CONFUSE",
    'probarriers_identified___inconven': "INCONVEN",
    'probarriers_identified___getinway': "GETINWAY",
    'probarriers_identified___noafford': "NOAFFORD",
    'probarriers_identified___chooseno': "CHOOSENO",
    'probarriers_identified___nopickup': "NOPICKUP",
    'probarriers_identified___insprob': "INSPROB",
    'probarriers_identified___nochild': "NOCHILD",
    'probarriers_identified___oth': "OTH",
    'probarriers_identified___none': "NONE",
}

demographics_columns = ['elhs_id', 'patientid', 'date_demographics', 'elhs_site_options', 'subject_dob', 'subject_age', 'age', 'dem_sex', 'gndident', 'ethnic', 'multi_race', 'race', 'race_factor', 'primlang', 'mar_statsdoh', 'live', 'educationsdoh', 'job', 'sexual_ornt']

no_na_demographics_columns = ['date_dem', 'elhs_site_options', 'subject_dob', 'subject_age', 'age', 'dem_sex', 'gndident', 'ethnic', 'race']

pros_columns = ['elhs_id', 'elhs_site_options', 'pro_form_completion', 'prosflastseiz', 'probarriers_identified', 'prosftypicalseiz', 'prosfdocument', 'prosfdoctype', 'proseiz_medadherelast1wk', 'proseiz_medsideeffects', 'proseiz_medsideeffectseverity', 'gad7score', 'gad7score_text', 'pro_phq_score', 'phq9score_text', 'nddiescore', 'nddiescore_text', 'promis10score', 'prommis10score_text']

no_na_pros_columns = ['prosflastseiz', 'probarriers_identified', 'prosftypicalseiz', 'prosfdocument', 'prosfdoctype', 'proseiz_medadherelast1wk', 'proseiz_medsideeffects', 'proseiz_medsideeffectseverity', 'gad7score', 'gad7score_text', 'pro_phq_score', 'phq9score_text']

visit_columns = ['elhs_id', 'patientid', 'visit_dt', 'provider', 'visit_type', 'patient_age_today', 'hasepilepsy', 'epistatus', 'hospvis', 'edvis', 'seizclus', 'pedqolcngroutine', 'pedqolsideff', 'medadhtaking', 'medadhsideeffects', 'medadhchecklist', 'medadhintervention', 'rescue_med', 'addepscr', 'adanxscr']

no_na_visit_columns = ['patient_age_today', 'hasepilepsy', 'epistatus', 'hospvis', 'edvis', 'seizclus', 'pedqolcngroutine', 'pedqolsideff', 'medadhtaking', 'medadhsideeffects', 'medadhchecklist', 'medadhintervention', 'rescue_med', 'addepscr', 'adanxscr']

history_all_columns = [
    "elhs_id", "patientid", "elhs_site_options", "dem_sex", "gndident", "ethnic", "race_factor",
    "history_completion_date", "newonset", "agefirstseiz", "eptype", "epysyndrome", "epysyndrome_grp",
    "epysyndrome_neo", "epysyndrome_chi", "epysyndrome_ado", "epysyndrome_any", "epysyndrome_dis",
    "epysyndrome_oth", "epsynothspec", "epet_gen_diag", "epet_gen_oth", "epet_strc_diag",
    "epet_strc_diag_2", "epet_strc_diag_3", "epet_strc_diag_4", "epet_strc_diag_5", "epet_dev_oth",
    "epet_oth", "epet_strc_diag_6", "etdrugres", "epsurghist", "eegdate", "eeglateraltiy", "eegloc",
    "eegothloc", "eegdet", "eegothdet", "antlobdate", "antloblat", "antlobdet", "antplusdate",
    "antpluslat", "antplusloc", "antplusothloc", "antplusdet", "amygdate", "amyglat", "amygapp",
    "amygothloc", "amygdet", "lesdate", "leslat", "lesloc", "lesothloc", "lesdet", "lesothdet",
    "lesplusdate", "lespluslat", "lesplusloc", "lesplusothloc", "lesplusdet", "lesplusothdet",
    "extemdate", "extemlat", "extemloc", "extemothloc", "extemdet", "extemothdet", "mulresdate",
    "mulreslat", "mulresloc", "mulresothloc", "mulresdet", "mulresothdet", "hemdate", "hemlat",
    "hemloc", "hemothloc", "hemdet", "hemothdet", "corpdate", "corploc", "corpothloc", "mstdate",
    "mstlat", "mstloc", "mstres", "mhtdate", "mhtlat", "mrgldate", "mrgllat", "mrglloc",
    "mrglothloc", "mrgldet", "mrglothdet", "linacdate", "linaclat", "linacloc", "linacothloc",
    "linacdet", "linacothdet", "eeglesdate", "eegleslat", "eeglesloc", "eeglesothloc",
    "eeglesdet", "eeglesothdet", "vnsdate", "vnslat", "theradate", "theralat", "theraloc",
    "theraothloc", "therares", "fendate", "fenlat", "fenloc", "fenothloc", "othoth", "othdate",
    "othlat"
]


excluded_history_all_columns = ['elhs_id', 'patientid', 'elhs_site_options', 'dem_sex', 'gndident', 'ethnic', 'race_factor']

history_columns = ["elhs_id", "history_completion_date", "newonset", "agefirstseiz", "eptype", "epysyndrome","etdrugres", "epsurghist", "epysyndrome_grp"]

no_na_history_columns = ['agefirstseiz', 'eptype', 'epysyndrome', 'newonset', 'agefirstseiz', 'etdrugres', 'epsurghist', 'epysyndrome_grp']

seiz_freq_columns = ['elhs_id', 'repeat_id', 'date_seizurefreq', 'redcap_repeat_instance',    'sz_type', 'seizreportby', 'freqlastseizdate', 'freqlastseizdate_text',    'seizfreq_text', 'seizfreq', 'seiztypepro', 'seizdescr',    'seizilae_text', 'seizilae', 'seizilae_epi_text', 'seizilae_epi',    'seizilae_nonepi_text', 'seizilae_nonepi', 'seizgenilae_text', 'seizgenilae', 'seizfocilae_text', 'seizfocilae',    'focal_wo_text', 'focal_wo', 'focal_w_text', 'focal_w',    'seizunkilae_text', 'seizunkilae', 'freqseizdiag']

data_wide_key_columns = ['elhs_site_options', 'subject_age', 'age', 'dem_sex', 'gndident', 'ethnic', 'race', 'prosflastseiz', 'probarriers_identified', 'medadhchecklist', 'seizilae', 'seizfreq']

medication_columns = ['elhs_id', 'redcap_repeat_instrument', 'redcap_repeat_instance', 'med_form_compl', 'asmed', 'asmedoth', 'ongoing', 'dose', 'unit',
                      'unitoth', 'freq', 'freqoth', 'prnoth', 'route', 'routeoth', 'stdate', 'enddate', 'reaoth', 'reasei', 'reased', 'reasec', 'readur',
                      'reaspec', 'form', 'indic', 'indicoth', 'rescue', 'medcomment']

rsnstop_text_mapping = {
    'rsnstop___inad': 'Inadequate seizure control',
    'rsnstop___seidio': 'Side effect(s), idiosyncratic',
    'rsnstop___sedose': 'Side effect(s), dose related',
    'rsnstop___sechro': 'Side effect(s), chronic',
    'rsnstop___inapp': 'Inappropriate for syndrome',
    'rsnstop___drugx': 'Drug interaction',
    'rsnstop___nonrx': 'Non-formulary or insurance restrictions',
    'rsnstop___cost': 'Cost or other financial',
    'rsnstop___nonad': 'Non-adherence, (discontinued by patient)',
    'rsnstop___pwseiz': 'Planned withdrawal (seizure free)',
    'rsnstop___pwpp': 'Planned withdrawal (pregnancy planning)',
    'rsnstop___pwoth': 'Planned withdrawal (other)',
    'rsnstop___pat': 'Patient request',
    'rsnstop___oth': 'Other',
    'rsnstop___unk': 'Unknown'
}
rsnstop_mapping = {
    'rsnstop___inad': 'INAD',
    'rsnstop___seidio': 'SEIDIO',
    'rsnstop___sedose': 'SEDOSE',
    'rsnstop___sechro': 'SECHRO',
    'rsnstop___inapp': 'INAPP',
    'rsnstop___drugx': 'DRUGX',
    'rsnstop___nonrx': 'NONRX',
    'rsnstop___cost': 'COST',
    'rsnstop___nonad': 'NONAD',
    'rsnstop___pwseiz': 'PWSEIZ',
    'rsnstop___pwpp': 'PWPP',
    'rsnstop___pwoth': 'PWOTH',
    'rsnstop___pat': 'PAT',
    'rsnstop___oth': 'OTH',
    'rsnstop___unk': 'UNK'
}
map_true_false = {True: 'Y', False: 'N'}

bin_edges = [-1, 4, 9, 14, 19, 24, 29, 34, 39, 44, 49, 54, 59, 64, 69, 74, 79, 84, 89, float('inf')]
bin_labels = ["<5", "5 - 9", "10 - 14", "15 - 19", "20 - 24", "25 - 29", "30 - 34", "35 - 39", "40 - 44",
              "45 - 49", "50 - 54", "55 - 59", "60 - 64", "65 - 69", "70 - 74", "75 - 79", "80 - 84", "85 - 89", "90+"]